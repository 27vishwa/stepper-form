import MultiStepDemo from "./components/MultiStep";

function App() {
  return (
    <>
      <MultiStepDemo />
    </>
  );
}

export default App;
