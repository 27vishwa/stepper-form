import React from "react";
import { useSelector } from "react-redux";
import Paragraph from "../common/Paragraph";
import { userSelector } from "../redux/slices/userSlice";

const OrderSummary = () => {
  const user = useSelector(userSelector); // Get user data from Redux

  // Destructure the values from the user object
  const { numberOfEmployees, selectedPrice, planType } = user;
  console.log("dfgdfgdfg", user);
  // Calculate total price
  const totalPrice = selectedPrice * (numberOfEmployees || 0);

  return (
    <div className="lg:col-span-4 col-span-12">
      <div className="bg-light-grey md:p-[30px] p-4 rounded-lg md:sticky top-[100px]">
        <Paragraph text20 className="font-medium mb-4">
          Order Summary
        </Paragraph>
        <ul>
          <li className="flex items-center justify-between gap-3 mb-2">
            <Paragraph text18 className="font-normal">
              {"Total Users:"}
            </Paragraph>
            <Paragraph text18 className="font-normal">
              {numberOfEmployees || 0} {/* Display number of users */}
            </Paragraph>
          </li>
          <li className="flex items-center justify-between gap-3 mb-2">
            <Paragraph text18 className="font-normal">
              {"Plan type:"}
            </Paragraph>
            <Paragraph text18 className="font-normal">
              {planType} {/* Display number of users */}
            </Paragraph>
          </li>
          <li className="flex items-center justify-between gap-3 mb-2">
            <Paragraph text18 className="font-normal">
              {"Selected Price:"}
            </Paragraph>
            <Paragraph text18 className="font-normal">
              ${selectedPrice || 0} {/* Display selected price */}
            </Paragraph>
          </li>
          <li className="flex items-center justify-between gap-3 mt-2 mb-4">
            <Paragraph text18 className="font-normal">
              {"Total Price:"}
            </Paragraph>
            <Paragraph text18 className="font-normal">
              ${totalPrice} {/* Display total price */}
            </Paragraph>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default OrderSummary;
