import React from "react";
import { Field, ErrorMessage } from "formik";
import FormLabel from "../../../common/form-components/FormLabel";
import { useDispatch } from "react-redux"; // Import useDispatch
import { setUser } from "../../../redux/slices/userSlice"; // Import your Redux action

const StepOne = () => {
  const dispatch = useDispatch(); // Get the dispatch function

  // Custom change handler
  const handleChange = (name, value) => {
    dispatch(setUser({ [name]: value })); // Dispatch the action to update Redux
  };

  return (
    <div className="md:pt-10 pt-7 w-full">
      <div className="grid grid-cols-12 lg:gap-6 gap-3 mb-4">
        {/* First Name */}
        <div className="md:col-span-6 col-span-12">
          <FormLabel>
            First Name
            <span className="text-site-red">*</span>
          </FormLabel>
          <Field name="firstName">
            {({ field }) => (
              <input
                {...field}
                type="text"
                placeholder="Enter first name"
                className="border border-gray-300 rounded-md p-2 w-full"
                onChange={(e) => {
                  field.onChange(e); // Call Formik's onChange
                  handleChange("firstName", e.target.value); // Dispatch to Redux
                }}
              />
            )}
          </Field>
          <ErrorMessage
            name="firstName"
            component="div"
            className="text-site-red text-sm"
          />
        </div>

        {/* Last Name */}
        <div className="md:col-span-6 col-span-12">
          <FormLabel>
            Last Name
            <span className="text-site-red">*</span>
          </FormLabel>
          <Field name="lastName">
            {({ field }) => (
              <input
                {...field}
                type="text"
                placeholder="Enter last name"
                className="border border-gray-300 rounded-md p-2 w-full"
                onChange={(e) => {
                  field.onChange(e); // Call Formik's onChange
                  handleChange("lastName", e.target.value); // Dispatch to Redux
                }}
              />
            )}
          </Field>
          <ErrorMessage
            name="lastName"
            component="div"
            className="text-site-red text-sm"
          />
        </div>

        {/* Email */}
        <div className="md:col-span-12 col-span-12">
          <FormLabel>
            Email
            <span className="text-site-red">*</span>
          </FormLabel>
          <Field name="email">
            {({ field }) => (
              <input
                {...field}
                type="email"
                placeholder="Enter email"
                className="border border-gray-300 rounded-md p-2 w-full"
                onChange={(e) => {
                  field.onChange(e); // Call Formik's onChange
                  handleChange("email", e.target.value); // Dispatch to Redux
                }}
              />
            )}
          </Field>
          <ErrorMessage
            name="email"
            component="div"
            className="text-site-red text-sm"
          />
        </div>

        {/* Company Name */}
        <div className="md:col-span-12 col-span-12">
          <FormLabel>
            Company Name
            <span className="text-site-red">*</span>
          </FormLabel>
          <Field name="companyName">
            {({ field }) => (
              <input
                {...field}
                type="text"
                placeholder="Enter company name"
                className="border border-gray-300 rounded-md p-2 w-full"
                onChange={(e) => {
                  field.onChange(e); // Call Formik's onChange
                  handleChange("companyName", e.target.value); // Dispatch to Redux
                }}
              />
            )}
          </Field>
          <ErrorMessage
            name="companyName"
            component="div"
            className="text-site-red text-sm"
          />
        </div>

        {/* Website */}
        <div className="md:col-span-12 col-span-12">
          <FormLabel>Website</FormLabel>
          <Field name="website">
            {({ field }) => (
              <input
                {...field}
                type="text"
                placeholder="Enter website URL"
                className="border border-gray-300 rounded-md p-2 w-full"
                onChange={(e) => {
                  field.onChange(e); // Call Formik's onChange
                  handleChange("website", e.target.value); // Dispatch to Redux
                }}
              />
            )}
          </Field>
          <ErrorMessage
            name="website"
            component="div"
            className="text-site-red text-sm"
          />
        </div>

        {/* Address */}
        <div className="md:col-span-12 col-span-12">
          <FormLabel>
            Address
            <span className="text-site-red">*</span>
          </FormLabel>
          <Field name="address">
            {({ field }) => (
              <input
                {...field}
                type="text"
                placeholder="Enter address"
                className="border border-gray-300 rounded-md p-2 w-full"
                onChange={(e) => {
                  field.onChange(e); // Call Formik's onChange
                  handleChange("address", e.target.value); // Dispatch to Redux
                }}
              />
            )}
          </Field>
          <ErrorMessage
            name="address"
            component="div"
            className="text-site-red text-sm"
          />
        </div>

        {/* City */}
        <div className="md:col-span-6 col-span-12">
          <FormLabel>
            City
            <span className="text-site-red">*</span>
          </FormLabel>
          <Field name="city">
            {({ field }) => (
              <input
                {...field}
                type="text"
                placeholder="Enter city"
                className="border border-gray-300 rounded-md p-2 w-full"
                onChange={(e) => {
                  field.onChange(e); // Call Formik's onChange
                  handleChange("city", e.target.value); // Dispatch to Redux
                }}
              />
            )}
          </Field>
          <ErrorMessage
            name="city"
            component="div"
            className="text-site-red text-sm"
          />
        </div>

        {/* State */}
        <div className="md:col-span-6 col-span-12">
          <FormLabel>
            State
            <span className="text-site-red">*</span>
          </FormLabel>
          <Field name="state">
            {({ field }) => (
              <input
                {...field}
                type="text"
                placeholder="Enter state"
                className="border border-gray-300 rounded-md p-2 w-full"
                onChange={(e) => {
                  field.onChange(e); // Call Formik's onChange
                  handleChange("state", e.target.value); // Dispatch to Redux
                }}
              />
            )}
          </Field>
          <ErrorMessage
            name="state"
            component="div"
            className="text-site-red text-sm"
          />
        </div>

        {/* ZIP Code */}
        <div className="md:col-span-6 col-span-12">
          <FormLabel>
            ZIP Code
            <span className="text-site-red">*</span>
          </FormLabel>
          <Field name="zip">
            {({ field }) => (
              <input
                {...field}
                type="text"
                placeholder="Enter ZIP code"
                className="border border-gray-300 rounded-md p-2 w-full"
                onChange={(e) => {
                  field.onChange(e); // Call Formik's onChange
                  handleChange("zip", e.target.value); // Dispatch to Redux
                }}
              />
            )}
          </Field>
          <ErrorMessage
            name="zip"
            component="div"
            className="text-site-red text-sm"
          />
        </div>
      </div>
    </div>
  );
};

export default StepOne;
