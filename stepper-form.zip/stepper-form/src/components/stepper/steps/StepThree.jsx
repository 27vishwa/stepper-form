import React from "react";
import { Field, ErrorMessage, useFormikContext } from "formik";
import { useDispatch } from "react-redux";
import FormLabel from "../../../common/form-components/FormLabel";
import {
  setPlanType,
  setSelectedPrice,
  setStartPlanDate,
} from "../../../redux/slices/userSlice";

const StepThree = () => {
  const { values, setFieldValue } = useFormikContext();
  const dispatch = useDispatch(); // Initialize useDispatch

  const handlePriceChange = (price) => {
    const totalPrice = price * (values.numberOfEmployees || 0);
    setFieldValue("selectedPrice", totalPrice);
    setFieldValue("planPrice", price);
    dispatch(setSelectedPrice(totalPrice)); // Dispatch action to update selected price in Redux
  };

  const handleStartPlanDateChange = (e) => {
    const date = e.target.value;
    setFieldValue("startPlanDate", date);
    dispatch(setStartPlanDate(date)); // Dispatch action to update start plan date in Redux
  };

  const handlePlanTypeChange = (e) => {
    const planType = e.target.value;
    setFieldValue("planType", planType);
    setFieldValue("selectedPrice", 0);
    setFieldValue("planPrice", 0);
    dispatch(setPlanType(planType)); // Dispatch action to update plan type in Redux
  };

  return (
    <div className="md:pt-10 pt-7 w-full">
      <div className="grid grid-cols-12 lg:gap-6 gap-3 mb-4">
        {/* Start Plan Date */}
        <div className="md:col-span-6 col-span-12">
          <FormLabel>Start Plan Date</FormLabel>
          <Field name="startPlanDate">
            {({ field }) => (
              <input
                {...field}
                type="date"
                onChange={handleStartPlanDateChange} // Use custom change handler
                className="border border-gray-300 rounded-md p-2 w-full"
              />
            )}
          </Field>
          <ErrorMessage
            name="startPlanDate"
            component="div"
            className="text-site-red text-sm"
          />
        </div>
        {/* Select Plan Type */}
        <div className="md:col-span-6 col-span-12">
          <FormLabel>Select Plan Type</FormLabel>
          <Field
            as="select"
            name="planType"
            onChange={handlePlanTypeChange} // Use custom change handler
            className="border border-gray-300 rounded-md p-2 w-full"
          >
            <option value="" label="Select plan type" />
            <option value="monthly" label="Monthly" />
            <option value="yearly" label="Yearly" />
          </Field>
          <ErrorMessage
            name="planType"
            component="div"
            className="text-site-red text-sm"
          />
        </div>
        {/* Plan Price */}
        {values.planType && (
          <div className="md:col-span-6 col-span-12">
            <FormLabel>Plan Price</FormLabel>
            <Field
              as="select"
              name="planPrice"
              onChange={(e) => handlePriceChange(e.target.value)} // Use custom change handler
              className="border border-gray-300 rounded-md p-2 w-full"
              value={values.planPrice || ""}
            >
              <option value="" label="Select price" />
              {values.planType === "monthly" && (
                <>
                  <option value={10} label="Gold - $10" />
                  <option value={20} label="Titanium - $20" />
                </>
              )}
              {values.planType === "yearly" && (
                <>
                  <option value={100} label="Gold - $100" />
                  <option value={200} label="Titanium - $200" />
                </>
              )}
            </Field>
            <ErrorMessage
              name="planPrice"
              component="div"
              className="text-site-red text-sm"
            />
          </div>
        )}
      </div>
    </div>
  );
};

export default StepThree;
