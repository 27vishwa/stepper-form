import React from "react";
import { Field, ErrorMessage, useFormikContext } from "formik";
import FormLabel from "../../../common/form-components/FormLabel";
import { useDispatch } from "react-redux";
import { setUser } from "../../../redux/slices/userSlice";

const technologyOptions = [
  { value: "react", label: "React" },
  { value: "node", label: "Node.js" },
  { value: "wordpress", label: "WordPress" },
  { value: "python", label: "Python" },
];

const StepTwo = () => {
  const { values, errors, setFieldValue } = useFormikContext();
  const dispatch = useDispatch();

  const handleCheckboxChange = (value) => {
    const currentTechnologies = values.technologies || [];
    if (currentTechnologies.includes(value)) {
      const updatedTechnologies = currentTechnologies.filter(
        (tech) => tech !== value
      );
      setFieldValue("technologies", updatedTechnologies);
      dispatch(setUser({ technologies: updatedTechnologies }));
    } else {
      const updatedTechnologies = [...currentTechnologies, value];
      setFieldValue("technologies", updatedTechnologies);
      dispatch(setUser({ technologies: updatedTechnologies }));
    }
  };

  const handleSelectChange = (e) => {
    const value = e.target.value;
    setFieldValue("numberOfEmployees", value);
    dispatch(setUser({ numberOfEmployees: value }));
  };

  const handleRadioChange = (value) => {
    setFieldValue("workFromHome", value);
    dispatch(setUser({ workFromHome: value }));
  };

  return (
    <div className="md:pt-10 pt-7 w-full">
      <div className="grid grid-cols-12 lg:gap-6 gap-3 mb-4">
        <div className="md:col-span-12 col-span-12">
          <FormLabel>Company Work Technology</FormLabel>
          <div className="flex flex-col space-y-2">
            {technologyOptions.map((option) => (
              <label key={option.value} className="flex items-center">
                <Field
                  type="checkbox"
                  name="technologies"
                  value={option.value}
                  className="mr-2"
                  onChange={() => handleCheckboxChange(option.value)}
                />
                {option.label}
              </label>
            ))}
          </div>
          {errors.technologies && (
            <div className="text-site-red text-sm">{errors.technologies}</div>
          )}
        </div>

        <div className="md:col-span-6 col-span-12">
          <FormLabel>Number of Employees</FormLabel>
          <Field
            as="select"
            name="numberOfEmployees"
            className="border border-gray-300 rounded-md p-2 w-full"
            onChange={handleSelectChange} // Use custom change handler
          >
            <option value="" label="Select number of employees" />
            {Array.from({ length: 50 }, (_, i) => (
              <option key={i + 1} value={i + 1} label={i + 1} />
            ))}
          </Field>
          {errors.numberOfEmployees && (
            <div className="text-site-red text-sm">
              {errors.numberOfEmployees}
            </div>
          )}
        </div>

        <div className="md:col-span-12 col-span-12">
          <FormLabel>Work From Home Policy</FormLabel>
          <div className="flex items-center space-x-4">
            <label className="flex items-center">
              <Field
                type="radio"
                name="workFromHome"
                value="yes"
                className="mr-2"
                onChange={() => handleRadioChange("yes")} // Use custom change handler
              />
              Yes
            </label>
            <label className="flex items-center">
              <Field
                type="radio"
                name="workFromHome"
                value="no"
                className="mr-2"
                onChange={() => handleRadioChange("no")} // Use custom change handler
              />
              No
            </label>
          </div>
          {errors.workFromHome && (
            <div className="text-site-red text-sm">{errors.workFromHome}</div>
          )}
        </div>
      </div>
    </div>
  );
};

export default StepTwo;
