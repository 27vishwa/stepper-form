import { Formik, Form } from "formik";
import React, { useEffect, useState } from "react";
import { Button } from "reactstrap";
import stepperValidationSchema from "../validations/stepperValidationSchema";
import StepOne from "./stepper/steps/StepOne";
import StepTwo from "./stepper/steps/StepTwo";
import StepThree from "./stepper/steps/StepThree";
import Stepper from "../common/Stepper";
import { useDispatch } from "react-redux";
import { setUser, resetUser } from "../redux/slices/userSlice"; // Import resetUser
import OrderSummary from "./OrderSummary";

const stepsContent = ["Step 1", "Step 2", "Step 3", "Step 4"];

const MultiStepDemo = () => {
  const [activeStep, setActiveStep] = useState(0);
  const currentValidationSchema = stepperValidationSchema[activeStep];
  let dispatch = useDispatch();
  const initialValues = {
    firstName: "",
    lastName: "",
    email: "",
    companyName: "",
    website: "",
    address: "",
    city: "",
    state: "",
    zip: "",
    technologies: [], // Add this line to store selected technologies
    numberOfEmployees: "",
    workFromHome: "",
    startPlanDate: "",
    userCount: 1, // Default to 1
    selectedPrice: 0, // Initialize to 0
    planType: "", // Add planType to initialValues
    planPrice: "", // Add planPrice to initialValues
  };

  const steps = [
    {
      name: "Step 1",
      content: <StepOne />,
    },
    {
      name: "Step 2",
      content: <StepTwo />,
    },
    { name: "Step 3", content: <StepThree /> },
  ];

  const _handleSubmit = async (values, actions) => {
    const errors = await actions.validateForm();
    console.log("Form Values:", values);

    if (Object.keys(errors).length === 0) {
      try {
        // Store the form values in Redux
        dispatch(setUser(values));

        // Check if it's the last step
        if (activeStep === steps.length - 1) {
          alert("Data submitted successfully!");

          // Clear the form values
          actions.resetForm(); // This will reset the form fields

          // Clear the Redux state
          dispatch(resetUser()); // Reset Redux state

          // Reset to step 1
          setActiveStep(0); // Reset to the first step
        } else {
          // Move to the next step
          setActiveStep((prev) => Math.min(prev + 1, steps.length - 1));
        }
      } catch (error) {
        console.error("Error during step processing:", error);
      } finally {
        actions.setSubmitting(false); // Ensure we reset submitting state
      }
    } else {
      actions.setTouched({});
      actions.setSubmitting(false);
    }
  };

  const _handleBack = () => {
    setActiveStep((prev) => Math.max(prev - 1, 0));
  };

  const isHorizontal = true;

  return (
    <section>
      <div className="container">
        <div className="md:py-[50px] py-[30px]">
          <Formik
            initialValues={initialValues}
            validationSchema={currentValidationSchema}
            onSubmit={_handleSubmit}
          >
            {({ values, isSubmitting }) => (
              <Form>
                <div className="grid grid-cols-12 gap-6">
                  <div className="lg:col-span-8 col-span-12">
                    <div
                      className={`flex ${
                        isHorizontal ? "flex-col" : "flex-row"
                      } items-start`}
                    >
                      <Stepper
                        steps={steps}
                        orientation="horizontal"
                        horizontalPosition={"self-center"}
                        activeStep={activeStep}
                      />
                      <div className="mt-30 flex justify-between w-full">
                        {activeStep !== 0 && (
                          <div className="flex items-center gap-3">
                            <Button
                              onClick={_handleBack}
                              className="font-semibold !p-2 !text-sm !rounded-lg hover:!bg-neutral-200"
                            >
                              {"Back"}
                            </Button>
                          </div>
                        )}
                        <div className="flex gap-3">
                          <Button
                            type="submit"
                            disabled={isSubmitting}
                            className={`font-semibold !p-2 !text-sm !rounded-lg hover:!bg-neutral-200 `}
                          >
                            {activeStep === steps.length - 1
                              ? "Submit"
                              : "Next"}
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <OrderSummary />
                </div>
              </Form>
            )}
          </Formik>
        </div>
      </div>
    </section>
  );
};

export default MultiStepDemo;
