import * as Yup from "yup";

export default [
  Yup.object({
    firstName: Yup.string().required("First name is required"),
    lastName: Yup.string().required("Last name is required"),
    email: Yup.string()
      .email("Invalid email format")
      .required("Email is required"),
    companyName: Yup.string().required("Company name is required"),
    address: Yup.string().required("Address is required"),
    city: Yup.string().required("City is required"),
    state: Yup.string().required("State is required"),
    zip: Yup.string().required("ZIP code is required"),
  }),
  Yup.object({
    technologies: Yup.array().min(1, "Select at least one technology"),
    numberOfEmployees: Yup.string().required("Number of employees is required"),
    workFromHome: Yup.string().required("Work from home policy is required"),
  }),
  Yup.object({
    startPlanDate: Yup.date().required("Start plan date is required"),
    userCount: Yup.number()
      .min(1, "At least 1 user is required")
      .required("Number of users is required"),
  }),
];
