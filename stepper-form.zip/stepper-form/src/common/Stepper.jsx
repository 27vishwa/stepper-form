import React from "react";
import Paragraph from "./Paragraph";

const Stepper = ({
  steps,
  orientation = "horizontal",
  horizontalPosition,
  activeStep,
}) => {
  const isHorizontal = orientation === "horizontal";

  return (
    <>
      <div
        className={`flex w-full ${isHorizontal ? "flex-row" : "flex-col"} ${
          horizontalPosition ? horizontalPosition : ""
        } items-center sm:gap-4 gap-2`}
      >
        {steps?.map((step, index) => (
          <div
            key={index}
            className="flex items-center sm:gap-3 gap-1 sm:w-1/3 relative z-0"
          >
            <div className="flex items-start sm:gap-3 gap-1 flex-col">
              <div
                className={`flex items-center justify-center w-[26px] h-[26px] rounded-full font-sm leading-[17px] 
                  ${
                    activeStep === index
                      ? "bg-site-yellow text-site-black"
                      : activeStep > index
                      ? "bg-site-yellow text-site-black" // Completed steps
                      : "bg-light-grey text-medium-grey"
                  }`}
              >
                {index + 1}
              </div>
              <Paragraph
                className={`${
                  activeStep === index
                    ? "text-site-black"
                    : activeStep > index
                    ? "text-site-black"
                    : "text-site-grey"
                } font-medium md:text-left text-center sm:text-base sm:leading-6 text-xs leading-[18px]`}
              >
                {step?.name}
              </Paragraph>
            </div>
            {index !== steps.length - 1 && (
              <div
                className={`border absolute top-[10px] left-[26px] -z-[1]  ${
                  isHorizontal
                    ? "border-t-[3px] w-full"
                    : "border-l-[3px] md:h-20 h-10"
                } 
                ${
                  activeStep > index
                    ? "border-site-yellow"
                    : "border-light-grey"
                }`}
              ></div>
            )}
          </div>
        ))}
      </div>

      {steps[activeStep].content}
    </>
  );
};

export default Stepper;
