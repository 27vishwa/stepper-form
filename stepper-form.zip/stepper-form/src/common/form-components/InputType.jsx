import { ErrorMessage, useField } from "formik";
import React, { useState } from "react";
import { HiOutlineEyeSlash } from "react-icons/hi2";
import { SlEye } from "react-icons/sl";

const InputType = ({
  type,
  name,
  disabled,
  placeholder,
  icon,
  className,
  isCompulsory,
  ref,
  value,
  showError = true,
  ...props
}) => {
  const [focused, setFocused] = useState(false);
  const [field] = useField(name);

  const [isVisible, setVisible] = useState(false);

  const onBlur = () => setFocused(false);
  const onFocus = () => setFocused(true);

  const toggle = () => {
    setVisible((prev) => !prev);
  };

  return (
    <div
      className={`form-control relative ${
        props.fullWidth ? "w-full flex-shrink" : "flex-shrink-0"
      }`}
    >
      <input
        {...props}
        {...field}
        placeholder={placeholder || ""}
        ref={ref}
        name={name}
        onFocus={onFocus}
        onBlur={(e) => {
          field.onBlur(e);
          onBlur();
        }}
        disabled={disabled ?? false}
        type={type === "password" ? (isVisible ? "text" : "password") : type}
        value={value}
        className={`${
          focused || field.value ? "hasFocus" : ""
        } appearance-none rounded-lg border border-medium-grey py-[13px] text-base leading-5 font-normal w-full focus:outline-0 focus:border-dark-grey placeholder:text-site-grey placeholder:font-normal placeholder:leading-5 text-site-black ${
          type === "search"
            ? "bg-search-icon bg-no-repeat bg-[left_16px_top_12px] ps-[48px_top_12px] pe-3"
            : type === "date"
            ? "px-[13px] !py-3"
            : "px-[15px]"
        } ${className || ""}`}
      />
      {type === "password" && (
        <span
          className="absolute right-4 top-[13px] cursor-pointer"
          onClick={toggle}
        >
          {isVisible ? (
            <HiOutlineEyeSlash size={20} color="#a4a4a5" />
          ) : (
            <SlEye size={20} color="#a4a4a5" />
          )}
        </span>
      )}
      {showError && (
        <ErrorMessage name={name}>
          {(msg) => (
            <div className="text-site-red text-sm font-medium">{msg}</div>
          )}
        </ErrorMessage>
      )}
    </div>
  );
};

export default InputType;
