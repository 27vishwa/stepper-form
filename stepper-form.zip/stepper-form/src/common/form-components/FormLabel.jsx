import React from "react";
import PropTypes from "prop-types";

function FormLabel({ className, children, ...props }) {
  return (
    <label
      {...props}
      className={`sm:text-sm sm:leading-[18px] text-site-black block mb-2 font-normal ${
        className ? className : ""
      }`}
    >
      {children}
    </label>
  );
}

// Adding PropTypes for type checking
FormLabel.propTypes = {
  className: PropTypes.string,
  children: PropTypes.node.isRequired,
};

export default FormLabel;
