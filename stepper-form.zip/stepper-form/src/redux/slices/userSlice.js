import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  firstName: "",
  lastName: "",
  email: "",
  companyName: "",
  website: "",
  address: "",
  city: "",
  state: "",
  zip: "",
  technologies: [], // Stores selected technologies
  numberOfEmployees: "",
  workFromHome: "",
  startPlanDate: "",
  selectedPrice: 0, // Initialize to 0
  planType: "", // Plan type
  planPrice: "", // Plan price
};

export const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    setUser: (state, action) => {
      return { ...state, ...action.payload };
    },
    resetUser: () => initialState, // New action to reset user state
    setTechnologies: (state, action) => {
      state.technologies = action.payload; // Update technologies
    },
    setNumberOfEmployees: (state, action) => {
      state.numberOfEmployees = action.payload; // Update number of employees
    },
    setWorkFromHome: (state, action) => {
      state.workFromHome = action.payload; // Update work from home
    },
    setStartPlanDate: (state, action) => {
      state.startPlanDate = action.payload; // Update start plan date
    },
    setPlanType: (state, action) => {
      state.planType = action.payload; // Update plan type
    },
    setSelectedPrice: (state, action) => {
      state.selectedPrice = action.payload; // Update selected price
    },
    setPlanPrice: (state, action) => {
      state.planPrice = action.payload; // Update plan price
    },
  },
});

// Selector to access user state
export const userSelector = (state) => state.user;

const { actions, reducer } = userSlice;

// Export individual action creators
export const {
  setUser,
  resetUser, // Export the new reset action
  setTechnologies,
  setNumberOfEmployees,
  setWorkFromHome,
  setStartPlanDate,
  setPlanType,
  setSelectedPrice,
  setPlanPrice,
} = actions;

export default reducer;
