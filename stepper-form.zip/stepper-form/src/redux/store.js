// src/store.js
import { configureStore } from "@reduxjs/toolkit";
import { persistStore } from "redux-persist";
import rootReducers from "./rootReducers";

const middlewares = []; // Define any custom middlewares here

export const store = configureStore({
  reducer: rootReducers,
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false, // Disable serializable state invariant checks if using non-serializable values
    }).concat(middlewares),
});

export const persistor = persistStore(store);

const exportStore = { store, persistor };

export default exportStore;
